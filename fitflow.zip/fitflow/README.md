# FitFlow — Student Fitness Platform

A professional, clean fitness web and mobile application built for Smart India Hackathon (SIH).

---

## Project Structure

```
fitflow/
├── web/
│   ├── index.html     — Full desktop/tablet web app
│   ├── styles.css     — Complete design system (light + dark)
│   └── app.js         — All application logic
│
└── mobile/
    ├── index.html     — Mobile-first PWA shell
    ├── mobile.css     — Mobile design system (light + dark)
    └── mobile.js      — Mobile application logic
```

---

## How to Run

### Web App
Open `web/index.html` in any modern browser. No build step required.

### Mobile App
Open `mobile/index.html` in any browser, or resize your browser to mobile width (390px). Works as a PWA on iOS and Android via Chrome / Safari.

For a local server (optional, improves font loading):
```
npx serve web
npx serve mobile
```

---

## Features

### Dashboard
- AI Coach insight banner with recovery score
- Day streak tracker with XP display
- 4 KPI cards: steps, calories, active minutes, sleep
- Daily goal progress bars with animated fills
- Weekly activity bar chart
- Recommended workouts with one-tap start

### Workouts
- 8 workouts across 4 categories: Cardio, Strength, HIIT, Yoga
- Category filter chips
- Workout detail bottom sheet / modal with full exercise list
- XP reward display

### Challenges
- 30-day hero challenge with live progress
- 4 weekly micro-challenges with progress bars
- College leaderboard (top 6 students)
- Achievement badge grid (locked/unlocked states)

### Nutrition
- 4 KPI cards: calories, protein, carbs, water
- Interactive water intake tracker (tap cups to log 250 ml)
- Macro progress bars
- Meal log

### Health
- 6 metric cards: HR, recovery, sleep, BMI, active time, XP
- BMI visual tracker
- Sleep bar chart
- Timestamped activity log

### AI Coach (chat)
- Conversational AI coach interface
- Quick-reply suggestion chips
- Smart responses for: workout selection, sleep, nutrition, recovery

---

## Design System

- **Primary font:** DM Sans (UI text)
- **Data font:** DM Mono (numbers, labels)
- **Accent:** Electric teal #0EA5B0
- **Base:** Deep navy #1E2A4A
- **Light mode:** Clean white surfaces, soft grey backgrounds
- **Dark mode:** Deep navy backgrounds, high-contrast text
- **Theme toggle:** Available on both web and mobile

---

## SIH Innovation Points

1. **AI coaching engine** — contextual recommendations based on simulated biometric data
2. **Gamification** — XP, levels, streaks, badges, leaderboard at college level
3. **Holistic tracking** — activity + nutrition + sleep + recovery in one platform
4. **Zero-dependency** — pure HTML, CSS, JS; no framework or build tool required
5. **Offline-capable** — all data stored in memory; works without internet after load
6. **Dual platform** — identical feature set on web and mobile from a single codebase
